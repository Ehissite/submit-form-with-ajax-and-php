# Form Submit using Ajax in PHP
 Submit form using Ajax in PHP. 
This application is about developing a Bootstrap form and write Ajax to submit the form. Then using PHP code insert the form data in a MySQL table. Also, it uses Bootstrap alert to display messages. For similar learning tutorials for web development visit my website https://codehow2.com.
# How To Use
1) Download the repository from https://github.com/sundarsau/php_ajax_form
2) Extract all the files under xampp/htdocs
3) Create the table in "test" database in MySQL by running users.sql
4) Run index.php in the browser
# License
This is an MIT license, you can modify the code according to your requirements
